﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace TmAPI.Migrations
{
    /// <inheritdoc />
    public partial class initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "HomeId",
                table: "Team",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "HomeId",
                table: "ServiceCategoty",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "HomeId",
                table: "RecentWork",
                type: "int",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Picture",
                table: "About",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<string>(
                name: "Targets",
                table: "About",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "Branchs",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MapLangAndLat = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    isMain = table.Column<bool>(type: "bit", nullable: false),
                    createAt = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Branchs", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Footer",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Picture = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AboutId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Footer", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Footer_About_AboutId",
                        column: x => x.AboutId,
                        principalTable: "About",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Home",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BannerTitle = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BannerSubtitle = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MainContent = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AboutId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Home", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Home_About_AboutId",
                        column: x => x.AboutId,
                        principalTable: "About",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "TermsAndServices",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TermsServicesScheme = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TermsAndServices", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Blogs",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Descreption = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BlogCategory = table.Column<int>(type: "int", nullable: true),
                    createAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    isActive = table.Column<bool>(type: "bit", nullable: false),
                    Picture = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    HomeId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Blogs", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Blogs_Home_HomeId",
                        column: x => x.HomeId,
                        principalTable: "Home",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "Questions",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Question = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Answer = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    creatAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    isActive = table.Column<bool>(type: "bit", nullable: false),
                    HomeId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Questions", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Questions_Home_HomeId",
                        column: x => x.HomeId,
                        principalTable: "Home",
                        principalColumn: "Id");
                });

            migrationBuilder.InsertData(
                table: "About",
                columns: new[] { "Id", "Discription", "Email", "EndWrok", "Message", "Picture", "StartWrok", "TagLine", "Targets", "Vision", "mobilePhone1", "mobilePhone2" },
                values: new object[] { 1, "We are committed to excellence.", "info@example.com", "05:00 PM", "Welcome to our world of innovation", "https://localhost:7065/uploads/about_us.jpg", "08:00 AM", "Leading the way in innovation", "To achieve market leadership by 2025", "To be a global leader in our industry", "123-456-7890", "098-765-4321" });

            migrationBuilder.InsertData(
                table: "Home",
                columns: new[] { "Id", "AboutId", "BannerSubtitle", "BannerTitle", "MainContent" },
                values: new object[] { 1, null, "Your success starts here", "Welcome to Our Site!", "We offer a variety of services to help you achieve your goals." });

            migrationBuilder.InsertData(
                table: "Footer",
                columns: new[] { "Id", "AboutId", "Picture" },
                values: new object[] { 1, 1, "footer_logo.png" });

            migrationBuilder.InsertData(
                table: "SocialLink",
                columns: new[] { "SocialLinkId", "AboutId", "Platform", "Url", "favicon" },
                values: new object[,]
                {
                    { 1, 1, "Facebook", "https://facebook.com/ourpage", null },
                    { 2, 1, "Twitter", "https://twitter.com/ourpage", null }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Team_HomeId",
                table: "Team",
                column: "HomeId");

            migrationBuilder.CreateIndex(
                name: "IX_ServiceCategoty_HomeId",
                table: "ServiceCategoty",
                column: "HomeId");

            migrationBuilder.CreateIndex(
                name: "IX_RecentWork_HomeId",
                table: "RecentWork",
                column: "HomeId");

            migrationBuilder.CreateIndex(
                name: "IX_Blogs_HomeId",
                table: "Blogs",
                column: "HomeId");

            migrationBuilder.CreateIndex(
                name: "IX_Footer_AboutId",
                table: "Footer",
                column: "AboutId");

            migrationBuilder.CreateIndex(
                name: "IX_Home_AboutId",
                table: "Home",
                column: "AboutId");

            migrationBuilder.CreateIndex(
                name: "IX_Questions_HomeId",
                table: "Questions",
                column: "HomeId");

            migrationBuilder.AddForeignKey(
                name: "FK_RecentWork_Home_HomeId",
                table: "RecentWork",
                column: "HomeId",
                principalTable: "Home",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ServiceCategoty_Home_HomeId",
                table: "ServiceCategoty",
                column: "HomeId",
                principalTable: "Home",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Team_Home_HomeId",
                table: "Team",
                column: "HomeId",
                principalTable: "Home",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_RecentWork_Home_HomeId",
                table: "RecentWork");

            migrationBuilder.DropForeignKey(
                name: "FK_ServiceCategoty_Home_HomeId",
                table: "ServiceCategoty");

            migrationBuilder.DropForeignKey(
                name: "FK_Team_Home_HomeId",
                table: "Team");

            migrationBuilder.DropTable(
                name: "Blogs");

            migrationBuilder.DropTable(
                name: "Branchs");

            migrationBuilder.DropTable(
                name: "Footer");

            migrationBuilder.DropTable(
                name: "Questions");

            migrationBuilder.DropTable(
                name: "TermsAndServices");

            migrationBuilder.DropTable(
                name: "Home");

            migrationBuilder.DropIndex(
                name: "IX_Team_HomeId",
                table: "Team");

            migrationBuilder.DropIndex(
                name: "IX_ServiceCategoty_HomeId",
                table: "ServiceCategoty");

            migrationBuilder.DropIndex(
                name: "IX_RecentWork_HomeId",
                table: "RecentWork");

            migrationBuilder.DeleteData(
                table: "SocialLink",
                keyColumn: "SocialLinkId",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "SocialLink",
                keyColumn: "SocialLinkId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "About",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DropColumn(
                name: "HomeId",
                table: "Team");

            migrationBuilder.DropColumn(
                name: "HomeId",
                table: "ServiceCategoty");

            migrationBuilder.DropColumn(
                name: "HomeId",
                table: "RecentWork");

            migrationBuilder.DropColumn(
                name: "Targets",
                table: "About");

            migrationBuilder.AlterColumn<string>(
                name: "Picture",
                table: "About",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);
        }
    }
}
