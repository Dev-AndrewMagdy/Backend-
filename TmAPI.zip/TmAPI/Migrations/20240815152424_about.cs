﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TmAPI.Migrations
{
    /// <inheritdoc />
    public partial class about : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "AboutId",
                table: "SocialLink",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_SocialLink_AboutId",
                table: "SocialLink",
                column: "AboutId");

            migrationBuilder.AddForeignKey(
                name: "FK_SocialLink_About_AboutId",
                table: "SocialLink",
                column: "AboutId",
                principalTable: "About",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_SocialLink_About_AboutId",
                table: "SocialLink");

            migrationBuilder.DropIndex(
                name: "IX_SocialLink_AboutId",
                table: "SocialLink");

            migrationBuilder.DropColumn(
                name: "AboutId",
                table: "SocialLink");
        }
    }
}
