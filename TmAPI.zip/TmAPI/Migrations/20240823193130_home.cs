﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TmAPI.Migrations
{
    /// <inheritdoc />
    public partial class home : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Home",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.AddColumn<string>(
                name: "BannerImage",
                table: "Home",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AlterColumn<string>(
                name: "Picture",
                table: "About",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.UpdateData(
                table: "About",
                keyColumn: "Id",
                keyValue: 1,
                column: "Picture",
                value: "about_us.jpg");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "BannerImage",
                table: "Home");

            migrationBuilder.AlterColumn<string>(
                name: "Picture",
                table: "About",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.UpdateData(
                table: "About",
                keyColumn: "Id",
                keyValue: 1,
                column: "Picture",
                value: "https://localhost:7065/uploads/about_us.jpg");

            migrationBuilder.InsertData(
                table: "Home",
                columns: new[] { "Id", "AboutId", "BannerSubtitle", "BannerTitle", "MainContent" },
                values: new object[] { 1, null, "Your success starts here", "Welcome to Our Site!", "We offer a variety of services to help you achieve your goals." });
        }
    }
}
