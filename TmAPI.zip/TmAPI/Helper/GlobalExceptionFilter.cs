﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc;
using TmAPI.Base;

namespace TmAPI.Helper
{
    public class GlobalExceptionFilter : IExceptionFilter
    {
        public void OnException(ExceptionContext context)
        {
            context.Result = new JsonResult(new ApiResponse<object>
            {
                Success = false,
                Message = context.Exception.Message,
                Data = null
            })
            {
                StatusCode = StatusCodes.Status500InternalServerError
            };
        }
    }

}
