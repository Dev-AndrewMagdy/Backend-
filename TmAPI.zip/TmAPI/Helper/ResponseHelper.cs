﻿using TmAPI.Base;

namespace TmAPI.Helper
{
    public class ResponseHelper
    {
        public static ApiResponse<T> ResultResponse<T>(bool success, T? data, string? message = "")
        {
            return new ApiResponse<T>
            {
                Success = success,
                Message = message,
                Data = data
            };
        }
    }
}
