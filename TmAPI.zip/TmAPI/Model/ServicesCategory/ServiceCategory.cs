using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using TmAPI.Base;

namespace TmAPI.Model.ServicesCategory
{
    public class ServiceCategoty : BaseDto
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string? CategoryName { get; set; }
        public string? CategoryDiscription { get; set; }
        public bool isActive { get; set; }
        public DateTime createAt { get; set; }
        [NotMapped]
        private string _Picture;
        public string Picture
        {
            get => $"{baseUrl()}{_Picture}";
            set => _Picture = value;
        }
    }
}