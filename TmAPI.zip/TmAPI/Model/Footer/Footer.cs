using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using TmAPI.Base;
using TmAPI.Model.AboutUs;

namespace TmAPI.Model.Footer
{
    public class Footer : BaseDto
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        [NotMapped]
        private string? _Picture;
        public string? Picture
        {
            get => $"{baseUrl()}{_Picture}";
            set => _Picture = value;
        }
        public int? AboutId { get; set; }
        public About? About { get; set; }
    }
}