namespace TmAPI.Model.Footer
{
    public class FooterRequest
    {
        public IFormFile? Picture { get; set; }
    }
}