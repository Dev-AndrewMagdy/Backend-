﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using TmAPI.Base;

namespace TmAPI.Model.Branch
{
    public class Branch 
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string? Address { get; set; }
        public string? MapLangAndLat { get; set; }
        public bool isMain { get; set; }
        public DateTime createAt { get; set; }
    }
}
