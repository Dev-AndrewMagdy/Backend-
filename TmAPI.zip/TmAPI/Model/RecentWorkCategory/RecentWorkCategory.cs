﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace TmAPI.Model.RecentWorkCategory
{
    public class RecentWorkCategory
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string? Name { get; set; }
        public bool isActive { get; set; }
        public DateTime createAt { get; set; }
    }

}
