using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using TmAPI.Base;

namespace Model.Services{

    public class Service : BaseDto {

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string? ServiceName { get; set; }
        public string? serviceDescription{ get; set; }

        private string? _picturePathName;
        public string Picture
        {
            get => $"{baseUrl()}{_picturePathName}";
            set => _picturePathName = value;
        }
        public bool isActive { get; set; }
        public DateTime createAt { get; set; }
        public int serviceCategory { get; set; }
    }
}