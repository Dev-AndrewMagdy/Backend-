﻿using System.ComponentModel.DataAnnotations;

namespace TmAPI.Model.Home
{
    public class HomeRequest
    {
        [Required]
        public required string BannerTitle { get; set; }
        [Required]
        public required string BannerSubtitle { get; set; }
        [Required]
        public required string MainContent { get; set; }
        public required IFormFile formFile {get; set;}
    }
}
