using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using TmAPI.Base;
using TmAPI.Model.AboutUs;
using TmAPI.Model.Blogs;
using TmAPI.Model.FAQ;
using TmAPI.Model.ServicesCategory;
using TmAPI.Model.Team;

namespace TmAPI.Model.Home
{
    public class Home : BaseDto
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string? BannerTitle { get; set; }
        public string? BannerSubtitle { get; set; }
        public string? MainContent { get; set; }
        public List<ServiceCategoty>? ServiceCategoty { get; set; }
        public List<RecentWorks.RecentWork>? RecentWorks { get; set; }
        public List<TeamUser>? Team { get; set; }
        public List<Blog>? Blog { get; set; }
        public List<Questions>? FAQ { get; set; }
        public About? About { get; set; }
        private string? _BannerImage;
        public string BannerImage
        {
            get => $"{baseUrl()}{_BannerImage}";
            set => BannerImage = value;
        }
    }
}