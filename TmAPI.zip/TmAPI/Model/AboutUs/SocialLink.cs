﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace TmAPI.Model.AboutUs
{
    public class SocialLink
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int SocialLinkId { get; set; }
        public string? Platform { get; set; } // e.g., "Facebook", "Twitter"
        public string? Url { get; set; }
        public string? favicon { get; set; }
        public int AboutId { get; set; }
        [JsonIgnore]
        public virtual About About { get; set; }
    }
}
