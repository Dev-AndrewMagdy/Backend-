using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using TmAPI.Base;

namespace TmAPI.Model.Blogs
{
    public class Blog : BaseDto
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
        public string? Title { get; set; }
        public string? Descreption { get; set; }
        public int? BlogCategory { get; set; }
        public DateTime? createAt { get; set; }
        public bool isActive { get; set; }
        [NotMapped]
        private string? _Picture;
        public string? Picture
        {
            get => $"{baseUrl()}{_Picture}";
            set => _Picture = value;
        }
    }
}