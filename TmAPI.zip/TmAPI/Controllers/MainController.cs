﻿using Microsoft.AspNetCore.Mvc;
using TmAPI.Base;
using TmAPI.Helper;
using TmAPI.Model.Home;
using TmAPI.Model.Footer;
using TmAPI.Repository.Main;

namespace TmAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MainController(IMainRepository mainRepository , ImagesProvider imagesProvider) : ControllerBase
    {
        [HttpGet("Home")]
        public async Task<ActionResult<ApiResponse<Home>>> Home()
        {
            Home? Home = await mainRepository.GetHomeAsync();
            return Ok(ResponseHelper.ResultResponse<Home>(true, Home, "Home"));
        }

        [HttpPut("setHome")]
        public async Task<ActionResult<ApiResponse<Home>>> setHome([FromForm] HomeRequest homeRequest)
        {
            string[] allowedFileExtentions = [".jpg", ".jpeg", ".png"];
            string? createdImageName = await imagesProvider.SaveFileAsync(homeRequest.formFile, allowedFileExtentions);
            Home home = new Home
            {
                Id = 1,
                BannerTitle = homeRequest.BannerTitle,
                BannerSubtitle = homeRequest.BannerSubtitle,
                MainContent = homeRequest.MainContent,
                BannerImage = createdImageName
            };

            bool updateState = await mainRepository.UpdateAsync(home);
            return Ok(ResponseHelper.ResultResponse<Home>(updateState, null, "Home updated"));
        }

        [HttpGet("Footer")]
        public async Task<ActionResult<ApiResponse<Footer>>> Footer()
        {
            //  About? about = await aboutRepository.GetAbout();
            return Ok(ResponseHelper.ResultResponse<Footer>(true, null, "Footer"));
        }

        [HttpPut("setFooter")]
        public async Task<ActionResult<ApiResponse<Footer>>> setFooter([FromForm] FooterRequest footerRequest)
        {
            //  About? about = await aboutRepository.GetAbout();
            return Ok(ResponseHelper.ResultResponse<Footer>(true, null, "Footer updated"));
        }
    }
}
