﻿using Microsoft.AspNetCore.Mvc;
using TmAPI.Base;
using TmAPI.Helper;
using TmAPI.Model.ServicesCategory;
using TmAPI.Repository.Categories;

namespace TmAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ServiceCategoryController(ICategoryRepository servicesRepository, ImagesProvider imagesProvider) : ControllerBase
    {
        [HttpPost("AddCategory")]
        public async Task<ActionResult<ApiResponse<ServiceCategoty>>> AddCategory([FromForm] ServiceCategoryRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new ApiResponse<ServiceCategoty>
                {
                    Success = false,
                    Message = "خطأ فى البيانات المدخلة",
                    Data = null
                });
            }

            string[] allowedFileExtentions = [".jpg", ".jpeg", ".png"];

            string createdImageName = await imagesProvider.SaveFileAsync(request.ImageFile, allowedFileExtentions);

            var category = new ServiceCategoty
            {
                CategoryName = request.CategoryName,
                CategoryDiscription = request.CategoryDiscription,
                Picture = createdImageName,
                isActive = request.isActive,
                createAt = DateTime.UtcNow,
            };

            if (await servicesRepository.AddAsync(category))
            {
                return Ok(ResponseHelper.ResultResponse<ServiceCategoty>(true, null, "تم اضافة المركز بنجاح"));
            }
            else
            {
                return BadRequest(ResponseHelper.ResultResponse<ServiceCategoty>(false, null, "فشل اضافة المركز"));
            }
        }

        [HttpPost("UpdateCategory")]
        public async Task<ActionResult<ApiResponse<ServiceCategoty>>> UpdateCategory([FromForm] ServiceCategoryRequest request, int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new ApiResponse<ServiceCategoty>
                {
                    Success = false,
                    Message = "خطأ فى البيانات المدخلة",
                    Data = null
                });
            }

            //* handle empty image reques/
            string[] allowedFileExtentions = [".jpg", ".jpeg", ".png"];
            string createdImageName = await imagesProvider.SaveFileAsync(request.ImageFile, allowedFileExtentions);

            var category = new ServiceCategoty
            {
                Id = id,
                CategoryName = request.CategoryName,
                CategoryDiscription = request.CategoryDiscription,
                Picture = createdImageName,
                isActive = request.isActive,
                createAt = DateTime.UtcNow,
            };

            if (await servicesRepository.UpdateAsync(category))
            {
                return Ok(ResponseHelper.ResultResponse<ServiceCategoty>(true, null, "تم اضافة المركز بنجاح"));
            }
            else
            {
                return BadRequest(ResponseHelper.ResultResponse<ServiceCategoty>(false, null, "فشل اضافة المركز"));
            }
        }


        [HttpGet("GetCategoryList")]
        public async Task<ActionResult<ApiResponse<IEnumerable<ServiceCategoty>>>> GetCategoryList()
        {
            IEnumerable<ServiceCategoty> data = await servicesRepository.GetAllAsync();
            return Ok(ResponseHelper.ResultResponse<IEnumerable<ServiceCategoty>>(true, data, "CategoryList"));
        }

  

    }
}
