﻿using Microsoft.EntityFrameworkCore;
using TmAPI.Base;
using TmAPI.Data;

namespace TmAPI.Repository.About
{
    public class AboutRepository : Repository<Model.AboutUs.About> , IAboutRepository
    {
        public AboutRepository(ApplicationDbContext applicationDbContext) : base(applicationDbContext) {}

        public async Task<Model.AboutUs.About> GetAbout()
        {
            return await _dbSet.Include(a => a.SocialLinks)
            .SingleOrDefaultAsync(a => a.Id == 1);
        }
    }
}
