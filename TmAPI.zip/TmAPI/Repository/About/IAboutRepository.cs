﻿using TmAPI.Base;

namespace TmAPI.Repository.About
{
    public interface IAboutRepository : IRepository<Model.AboutUs.About>{

        Task<Model.AboutUs.About> GetAbout();
    
    }
}
