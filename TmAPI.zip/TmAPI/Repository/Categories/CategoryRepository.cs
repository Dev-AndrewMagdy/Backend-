﻿using TmAPI.Base;
using TmAPI.Data;
using TmAPI.Model.ServicesCategory;

namespace TmAPI.Repository.Categories
{
    public class CategoryRepository : Repository<ServiceCategoty>, ICategoryRepository
    {
        public CategoryRepository(ApplicationDbContext dbContext) : base(dbContext) { }

    }
}
