﻿using TmAPI.Base;
using TmAPI.Model.ServicesCategory;

namespace TmAPI.Repository.Categories
{
    public interface ICategoryRepository : IRepository<ServiceCategoty>
    {

    }
}
