﻿using TmAPI.Base;
using TmAPI.Data;
using TmAPI.Model.ConactUs;

namespace TmAPI.Repository.Contact
{
    public class ConactUsRepository :Repository<ContactUs>, IContactUsRepository
    {
        public ConactUsRepository(ApplicationDbContext applicationDbContext) : base(applicationDbContext) { }
    }
}
