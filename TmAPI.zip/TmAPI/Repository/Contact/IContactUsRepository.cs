﻿using TmAPI.Base;
using TmAPI.Model.ConactUs;

namespace TmAPI.Repository.Contact
{
    public interface IContactUsRepository : IRepository<ContactUs>
    {

    }
}
