﻿using TmAPI.Base;
using TmAPI.Data;
using TmAPI.Model.Team;

namespace TmAPI.Repository.TeamRepository
{
    public class TeamRepository : Repository<TeamUser>, IteamRepository
    {
        public TeamRepository(ApplicationDbContext dbContext) : base(dbContext) { }
    }
}
