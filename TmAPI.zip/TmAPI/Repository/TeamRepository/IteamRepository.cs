﻿using TmAPI.Base;
using TmAPI.Model.Team;

namespace TmAPI.Repository.TeamRepository
{
    public interface IteamRepository : IRepository<TeamUser>{}
}
