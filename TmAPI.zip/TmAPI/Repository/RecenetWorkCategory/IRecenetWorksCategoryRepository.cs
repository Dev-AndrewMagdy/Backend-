﻿using TmAPI.Base;
using TmAPI.Model.RecentWorkCategory;

namespace TmAPI.Repository.RecenetWorkCategory
{
    public interface IRecenetWorksCategoryRepository :IRepository<RecentWorkCategory>
    {
    }
}
