﻿using TmAPI.Base;
using TmAPI.Data;
using TmAPI.Model.RecentWorkCategory;

namespace TmAPI.Repository.RecenetWorkCategory
{
    public class RecenetWorksCategoryRepository :Repository<RecentWorkCategory> , IRecenetWorksCategoryRepository
    {
        public RecenetWorksCategoryRepository(ApplicationDbContext applicationDbContext) : base(applicationDbContext) { }
    }
}
