﻿using TmAPI.Base;
using TmAPI.Data;

namespace TmAPI.Repository.RecentWork
{
    public class RecentWorkRepository : Repository<Model.RecentWorks.RecentWork> ,IRecentWorkRepository
    {
        public RecentWorkRepository(ApplicationDbContext applicationDbContext) : base(applicationDbContext) { }
    }
}
