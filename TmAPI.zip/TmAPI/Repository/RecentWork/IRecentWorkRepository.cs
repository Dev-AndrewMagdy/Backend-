﻿using TmAPI.Base;

namespace TmAPI.Repository.RecentWork
{
    public interface IRecentWorkRepository :IRepository<Model.RecentWorks.RecentWork>
    {
    }
}
