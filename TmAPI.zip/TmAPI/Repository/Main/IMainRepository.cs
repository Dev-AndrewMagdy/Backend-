﻿using TmAPI.Base;
using TmAPI.Model.Home;

namespace TmAPI.Repository.Main
{
    public interface IMainRepository : IRepository<Home>
    {
        Task<Home?> GetHomeAsync();
    }
}
