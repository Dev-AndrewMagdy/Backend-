﻿using Model.Services;
using TmAPI.Base;

namespace TmAPI.Repository.Services
{
    public interface IServicesRepository : IRepository<Service>
    {
        Task<IEnumerable<Service>> getByCategory(int categoryId);
    }
}
