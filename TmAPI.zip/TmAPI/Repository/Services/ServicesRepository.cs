﻿using Microsoft.EntityFrameworkCore;
using Model.Services;
using TmAPI.Base;
using TmAPI.Data;
using TmAPI.Repository.Services;

namespace TmAPI.Repository.Authentication
{
    public class ServicesRepository : Repository<Service>, IServicesRepository
    {
        public ServicesRepository(ApplicationDbContext dbContext) : base(dbContext) {}

        public async Task<IEnumerable<Service>> getByCategory(int categoryId)
        {
            return await _dbSet.Where(p => p.serviceCategory == categoryId).ToListAsync();
        }

    }
 
}