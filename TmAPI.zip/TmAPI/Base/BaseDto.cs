﻿namespace TmAPI.Base
{
    public class BaseDto { 
    
        public string baseUrl() { return "https://localhost:7065/uploads/"; }
    }
}
